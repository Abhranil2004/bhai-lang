import InterpreterModule from "./module/interpreterModule";

export { default as RuntimeException } from "./exceptions/runtimeException";

export default InterpreterModule.getInterpreter();
